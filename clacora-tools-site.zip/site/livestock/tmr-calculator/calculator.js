/* ============================================================
   TMR / Cattle Feed Calculator — calculation engine
   ============================================================ */
(function(){
  const fmt = window.ClacoraTools.fmt;
  const el = (id)=>document.getElementById(id);

  // Feed composition — approximate, as-fed basis. DM = dry matter %,
  // CP = crude protein (% of DM), TDN = total digestible nutrients (% of DM, energy proxy).
  const FEEDS = [
    {key:'corn',    name:'Corn (maize grain)', dm:0.88, cp:0.09, tdn:0.80, price:55},
    {key:'wbran',   name:'Wheat bran',         dm:0.89, cp:0.15, tdn:0.65, price:45},
    {key:'barley',  name:'Barley',             dm:0.88, cp:0.11, tdn:0.78, price:60},
    {key:'soymeal', name:'Soybean meal',       dm:0.90, cp:0.44, tdn:0.80, price:140},
    {key:'cscake',  name:'Cottonseed cake',    dm:0.91, cp:0.28, tdn:0.70, price:90},
    {key:'silage',  name:'Maize silage',       dm:0.30, cp:0.08, tdn:0.65, price:12},
    {key:'hay',     name:'Grass hay',          dm:0.88, cp:0.08, tdn:0.55, price:25},
    {key:'straw',   name:'Wheat straw',        dm:0.90, cp:0.03, tdn:0.40, price:15},
    {key:'molasses',name:'Molasses',           dm:0.75, cp:0.04, tdn:0.72, price:60},
    {key:'mineral', name:'Mineral mix',        dm:0.95, cp:0,    tdn:0,    price:180},
    {key:'salt',    name:'Salt',               dm:0.99, cp:0,    tdn:0,    price:40},
  ];

  // Daily DM intake as a fraction of body weight, plus extra DM per litre of milk for lactating animals.
  const DMI_PROFILE = {
    'dairy-cow':   {dry:0.020, lactating:0.030, cp:{dry:0.12, lactating:0.16}, tdn:{dry:0.55, lactating:0.68}},
    'buffalo':     {dry:0.018, lactating:0.025, cp:{dry:0.11, lactating:0.14}, tdn:{dry:0.55, lactating:0.65}},
    'beef':        {dry:0.022, lactating:0.022, cp:{dry:0.12, lactating:0.12}, tdn:{dry:0.65, lactating:0.65}},
    'goat':        {dry:0.032, lactating:0.038, cp:{dry:0.12, lactating:0.14}, tdn:{dry:0.55, lactating:0.60}},
    'sheep':       {dry:0.028, lactating:0.033, cp:{dry:0.11, lactating:0.13}, tdn:{dry:0.55, lactating:0.60}},
  };

  // Starting-point templates (kg as-fed/day) at a reference body weight/milk yield — scaled to the user's animal.
  const TEMPLATES = {
    'dairy-cow': {refDMI:14, mix:{silage:15, straw:2, wbran:2, cscake:1.5, mineral:0.1, salt:0.05}},
    'buffalo':   {refDMI:12, mix:{silage:12, straw:3, wbran:1.5, cscake:1, mineral:0.1, salt:0.05}},
    'beef':      {refDMI:10, mix:{silage:8, straw:3, corn:1.5, cscake:0.8, mineral:0.08, salt:0.04}},
    'goat':      {refDMI:1.6, mix:{hay:1, wbran:0.3, cscake:0.15, mineral:0.02, salt:0.01}},
    'sheep':     {refDMI:1.4, mix:{hay:0.9, wbran:0.25, cscake:0.12, mineral:0.02, salt:0.01}},
  };

  function requirement(){
    const animal = el('animal').value;
    const bw = parseFloat(el('bodyWeight').value)||0;
    const status = el('status').value; // dry | lactating
    const milk = status==='lactating' ? (parseFloat(el('milkYield').value)||0) : 0;
    const pregnant = el('pregnant').checked;
    const profile = DMI_PROFILE[animal];

    let dmi = bw * profile[status];
    if(status==='lactating') dmi += milk*0.3;
    if(pregnant) dmi *= 1.1;

    const cpPct = profile.cp[status];
    const tdnPct = profile.tdn[status];
    return { dmi, cpKg: dmi*cpPct, tdnKg: dmi*tdnPct, cpPct, tdnPct };
  }

  function buildFeedTable(){
    const wrap = el('feedTable');
    wrap.innerHTML = FEEDS.map(f=>`
      <div class="appliance-row" style="grid-template-columns:1.6fr .7fr .9fr .7fr">
        <div><div class="name">${f.name}</div><div class="w">DM ${Math.round(f.dm*100)}% · CP ${Math.round(f.cp*100)}% · TDN ${Math.round(f.tdn*100)}%</div></div>
        <div><input type="number" min="0" step="0.1" data-feed="${f.key}" data-role="kg" placeholder="kg/day" aria-label="${f.name} kg per day"></div>
        <div style="font-size:.78rem;color:var(--muted-2)">PKR/kg</div>
        <div><input type="number" min="0" step="1" data-feed="${f.key}" data-role="price" value="${f.price}" aria-label="${f.name} price per kg"></div>
      </div>
    `).join('');
    wrap.querySelectorAll('input').forEach(i=>i.addEventListener('input', render));
  }

  function getRation(){
    const rows = el('feedTable').querySelectorAll('.appliance-row');
    const ration = [];
    rows.forEach(row=>{
      const kgInput = row.querySelector('[data-role="kg"]');
      const priceInput = row.querySelector('[data-role="price"]');
      const key = kgInput.dataset.feed;
      const kg = parseFloat(kgInput.value)||0;
      const price = parseFloat(priceInput.value)||0;
      if(kg>0){
        const f = FEEDS.find(x=>x.key===key);
        ration.push({...f, kg, price});
      }
    });
    return ration;
  }

  function loadPreset(){
    const animal = el('animal').value;
    const tmpl = TEMPLATES[animal];
    const req = requirement();
    const scale = req.dmi>0 ? req.dmi/tmpl.refDMI : 1;
    // clear all
    el('feedTable').querySelectorAll('[data-role="kg"]').forEach(i=>i.value='');
    Object.keys(tmpl.mix).forEach(key=>{
      const input = el('feedTable').querySelector(`[data-feed="${key}"][data-role="kg"]`);
      if(input) input.value = (tmpl.mix[key]*scale).toFixed(2);
    });
    render();
  }

  function render(){
    const req = requirement();
    const ration = getRation();

    const dmSupplied = ration.reduce((s,f)=>s+f.kg*f.dm,0);
    const cpSupplied = ration.reduce((s,f)=>s+f.kg*f.dm*f.cp,0);
    const tdnSupplied = ration.reduce((s,f)=>s+f.kg*f.dm*f.tdn,0);
    const costDay = ration.reduce((s,f)=>s+f.kg*f.price,0);

    el('reqDMI').textContent = fmt(req.dmi,1);
    el('reqCP').textContent = fmt(req.cpKg,2);
    el('reqTDN').textContent = fmt(req.tdnKg,2);
    el('rCostDay').textContent = fmt(costDay,0);
    el('rCostMonth').textContent = fmt(costDay*30,0);

    function statusBadge(supplied, needed){
      if(needed<=0) return '';
      const pct = supplied/needed*100;
      if(pct<90) return `<span style="color:var(--danger);font-weight:700">Deficit (${fmt(pct,0)}%)</span>`;
      if(pct>115) return `<span style="color:var(--solar-600);font-weight:700">Surplus (${fmt(pct,0)}%)</span>`;
      return `<span style="color:var(--psx-600);font-weight:700">Adequate (${fmt(pct,0)}%)</span>`;
    }

    el('breakdownBody').innerHTML = `
      <tr><td>Dry matter intake</td><td class="num">${fmt(dmSupplied,2)} / ${fmt(req.dmi,2)} kg</td><td>${statusBadge(dmSupplied,req.dmi)}</td></tr>
      <tr><td>Crude protein supplied</td><td class="num">${fmt(cpSupplied,2)} / ${fmt(req.cpKg,2)} kg</td><td>${statusBadge(cpSupplied,req.cpKg)}</td></tr>
      <tr><td>Energy (TDN) supplied</td><td class="num">${fmt(tdnSupplied,2)} / ${fmt(req.tdnKg,2)} kg</td><td>${statusBadge(tdnSupplied,req.tdnKg)}</td></tr>
      <tr><td>Total as-fed ration</td><td class="num">${fmt(ration.reduce((s,f)=>s+f.kg,0),2)} kg/day</td><td></td></tr>
      <tr><td>Feed cost</td><td class="num">PKR ${fmt(costDay,0)}/day</td><td></td></tr>
    `;

    saveToStorage();
  }

  function saveToStorage(){
    try{
      const ids = ['animal','bodyWeight','status','milkYield'];
      const o={}; ids.forEach(id=>{const n=el(id); if(n) o[id]=n.value;});
      o.pregnant = el('pregnant').checked;
      const kgVals = {};
      el('feedTable').querySelectorAll('[data-role="kg"]').forEach(i=>{ if(i.value) kgVals[i.dataset.feed]=i.value; });
      o.ration = kgVals;
      localStorage.setItem('clacora-tmr-v1', JSON.stringify(o));
    }catch(e){}
  }
  function loadFromStorage(){
    try{
      const raw = localStorage.getItem('clacora-tmr-v1');
      if(!raw) return;
      const o = JSON.parse(raw);
      ['animal','bodyWeight','status','milkYield'].forEach(id=>{const n=el(id); if(n && o[id]!==undefined) n.value=o[id];});
      if(o.pregnant) el('pregnant').checked = true;
      if(o.ration){
        Object.keys(o.ration).forEach(key=>{
          const input = el('feedTable').querySelector(`[data-feed="${key}"][data-role="kg"]`);
          if(input) input.value = o.ration[key];
        });
      }
    }catch(e){}
  }

  function toggleLactationField(){
    el('milkField').style.display = el('status').value==='lactating' ? 'flex':'none';
  }

  function resetAll(){
    localStorage.removeItem('clacora-tmr-v1');
    el('bodyWeight').value=''; el('milkYield').value=''; el('pregnant').checked=false;
    el('feedTable').querySelectorAll('[data-role="kg"]').forEach(i=>i.value='');
    render();
  }

  function copyResult(){
    const req = requirement();
    const text = `TMR ration (Clacora Tools):\nAnimal: ${el('animal').selectedOptions[0].textContent}\nRequired DMI: ${fmt(req.dmi,1)} kg/day\nFeed cost: PKR ${el('rCostDay').textContent}/day (PKR ${el('rCostMonth').textContent}/month)`;
    navigator.clipboard?.writeText(text).then(()=>{
      const b=el('copyBtn'); const old=b.textContent; b.textContent='Copied!'; setTimeout(()=>b.textContent=old,1500);
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    buildFeedTable();
    loadFromStorage();
    toggleLactationField();
    el('animal').addEventListener('change', render);
    el('status').addEventListener('change', ()=>{toggleLactationField(); render();});
    el('bodyWeight').addEventListener('input', render);
    el('milkYield').addEventListener('input', render);
    el('pregnant').addEventListener('change', render);
    el('presetBtn').addEventListener('click', loadPreset);
    el('resetBtn').addEventListener('click', resetAll);
    el('copyBtn').addEventListener('click', copyResult);
    el('printBtn').addEventListener('click', ()=>window.print());
    el('shareBtn').addEventListener('click', ()=>{
      navigator.clipboard?.writeText(window.location.href);
      const b=el('shareBtn'); const old=b.textContent; b.textContent='Link copied!'; setTimeout(()=>b.textContent=old,1500);
    });
    if(!el('bodyWeight').value) el('bodyWeight').value = 400;
    render();
  });
})();
