# Clacora Tools — Free Smart Calculators

Yeh phase-1 build hai: design system + homepage + pehla flagship calculator
(**Solar Load & Battery Calculator**) fully working state mein.

## Kyun static HTML/CSS/JS?

Is environment mein internet access disabled hai (npm registry tak bhi nahi
pahonch sakte), isliye Next.js jaisa build-tool wala stack yahan install
nahi ho sakta. Isliye maine **dependency-free static site** banayi hai —
koi build step nahi chahiye, seedha kisi bhi static host (Netlify, Vercel,
Cloudflare Pages, GitHub Pages) par upload karke live ho jayegi.

Jab aap apne (network-enabled) machine par Next.js + TypeScript + Tailwind
mein migrate karna chahein, yehi design system (`assets/css/styles.css`
ke tokens) aur calculation engine (`calculator.js` ki logic) seedha React
components mein port ho sakti hai — koi dobara research nahi karni paregi.

## Structure

```
/
├── index.html                     ← Homepage
├── robots.txt
├── sitemap.xml
├── assets/
│   ├── css/styles.css             ← Design system (tokens + components)
│   └── js/main.js                 ← Shared: theme toggle, number formatting
└── solar/
    └── solar-load-calculator/
        ├── index.html             ← SEO landing page + calculator UI
        └── calculator.js          ← Calculation engine + appliance library
```

## Design system

- **Type**: Fraunces (display, headings) + Inter (body) + IBM Plex Mono
  (numbers/results) — deliberately not the "cream + serif + terracotta"
  AI-template look; navy/teal base with category-specific accents
  (solar = amber, PSX = green, agriculture = green, livestock = tan,
  finance = blue).
- **Tokens**: sab colors, radii, shadows `:root` mein CSS variables ke
  taur par (`styles.css` ke top par) — naya category add karna sirf
  ek accent-color set define karna hai.
- **Components**: `.panel`, `.field`, `.seg`, `.result-hero`,
  `.scenario-card`, `.appliance-row`, `.faq-item` — yeh sab reusable
  hain, koi bhi naya calculator inhi classes se bana sakta hai.

## Calculator engine pattern (Calculator #6, #50, #100 ke liye)

Har calculator ki apni `calculator.js` file hoti hai jo:
1. Reference data define karti hai (appliance library / crop database /
   feed database — jo bhi calculator ke liye zaroori ho), **saaf comment
   ke sath ke yeh estimate hai, source kya hai**.
2. `computeCore()` jaisa ek pure function likhti hai jo sirf numbers
   leta hai, koi DOM nahi chhuta — is se automated testing aasan hoti hai.
3. `render()` function results ko HTML mein daalta hai.
4. `localStorage` mein last input save karta hai (privacy: sab
   calculation client-side, kuch bhi server ko nahi jaata).

Naya calculator banane ke liye: isi teen-file pattern (`index.html` +
`calculator.js`, `styles.css` reuse) ko copy karke sirf domain logic
badalni hai.

## Ab tak complete — 5 calculators live

- [x] Homepage (hero, search, 5 category cards, popular calculators grid)
- [x] Design system (`styles.css`) — poori site is par based hogi
- [x] **Solar Load & Battery Calculator** (`/solar/solar-load-calculator/`)
      — appliance library (8 categories), bill-based mode,
      on-grid/hybrid/off-grid, 12 Pakistani shehar ke sun-hours, battery
      Ah/kWh, inverter sizing, 3 scenarios (conservative/recommended/
      high-demand), editable pricing + payback, energy-by-category chart.
- [x] **Crop Fertilizer Calculator** (`/agriculture/crop-fertilizer-calculator/`)
      — 10-crop database (wheat, rice, maize, cotton, sugarcane, potato,
      tomato, onion, chili, soybean), 5 area units (acre/hectare/kanal/
      marla/sqm), soil-type adjustment, target-yield scaling, DAP→N credit
      logic, Urea/DAP-SSP/SOP-MOP bag counts, application-split plan.
- [x] **TMR / Cattle Feed Calculator** (`/livestock/tmr-calculator/`)
      — 5 animal types (dairy cow, buffalo, beef, goat, sheep), DMI/CP/TDN
      requirement engine, 11-feed database, ration builder with live
      deficit/adequate/surplus status, one-click scaled starting-ration
      preset, daily + monthly feed cost.
- [x] **PSX Profit/Loss Calculator** (`/psx/psx-profit-loss-calculator/`)
      — unlimited buy/sell transaction rows, weighted average cost basis,
      editable brokerage/other-charges/CGT, dividend income, break-even
      price, ROI, remaining-holding unrealized gain/loss, investment vs
      sale vs net-P/L chart.
- [x] **Loan EMI & Amortization Calculator** (`/finance/loan-emi-calculator/`)
      — monthly/biweekly/weekly/yearly frequency, full amortization
      schedule (scrollable), yearly principal-vs-interest chart, extra-
      payment simulator (interest + time saved), Loan A vs Loan B
      side-by-side comparison mode.

Har calculator: FAQ schema, SoftwareApplication schema, methodology,
assumptions, disclaimer, worked example (jahan applicable), related
calculators, localStorage auto-save, copy/share/print, mobile-first
responsive layout.

- [x] **5 category pages** (`/solar/`, `/psx/`, `/agriculture/`,
      `/livestock/`, `/finance/`) — har ek mein: intro content unique
      hai (thin/duplicate content nahi), live calculator card(s),
      future-calculator "Coming soon" cards, category-level guide
      section, FAQ, BreadcrumbList schema.
- [x] **About Us** (`/about/`) — mission, methodology philosophy, privacy
      summary.
- [x] **Contact Us** (`/contact/`) — form (mailto: fallback, koi backend
      network nahi tha), direct email bhi diya.
- [x] **Privacy Policy** (`/privacy/`) — client-side calculation, localStorage
      ka use, koi account/signup nahi, koi sensitive data collect nahi.
- [x] Sab pages ke footer mein About/Contact/Privacy links consistent hain.

- [x] **Custom 404 page** (`/404.html`) — search bar + quick links back to
      home and popular calculators, `noindex` so it doesn't get indexed.
      Netlify and GitHub Pages both auto-detect a root `404.html`; on
      Vercel or a custom server you may need to point the error route
      to it explicitly.
- [x] **Blog** (`/blog/`) — 6 in-depth guides (500-800 words each, no
      thin content), one per calculator's core concept, each linking
      back to its calculator and forward to a related article:
      - How Much Solar System Do You Actually Need?
      - Lithium vs Lead-Acid: A Real Cost Comparison
      - What Actually Eats Your PSX Profit
      - Fertilizer Timing: Why "When" Matters as Much as "How Much"
      - Dry Matter Intake: The Number Every Ration Starts With
      - EMI vs Total Interest: The Monthly Payment Isn't the Whole Story
      Every article has Article schema, a canonical URL, and is in the
      sitemap. "Blog" link added to the header nav and footer across
      every page on the site.
- [x] Contact page uses the real inbox: **ranaaakas@gmail.com**.

**A note on scale:** the original brief mentions eventually reaching
hundreds of calculator pages and the person managing this project
asked for "700 blog pages." That's not something to generate in one
batch — the brief's own SEO rule says thin, low-value pages hurt
rather than help, and 700 genuinely useful articles take real
research time, not a single generation pass. The right way to get
there is what's happening here: a handful of solid, well-linked
articles per batch, added over time. Ask for the next batch whenever
you want it — same depth, same standard, just more of them.

## Dark-mode bugs found via visual testing (screenshot audit)

While demonstrating the site with real browser screenshots (Playwright),
three real dark-mode bugs surfaced that no code-level check would have
caught — they're visual/contrast issues, not syntax errors:

1. **Headings were nearly invisible in dark mode.** All `h1`-`h4`,
   card titles, footer headings, etc. used a fixed dark navy color
   (`--navy-950`) that never changed with the theme — so on the dark
   background, heading text was almost the same color as its background.
2. **Focused inputs broke in dark mode.** `.field input:focus` had a
   hardcoded `background:#fff`, so clicking into any field in dark mode
   put light-colored text on a white box — unreadable.
3. **The header bar didn't go dark at all.** `.site-header` had a
   hardcoded light `rgba()` background instead of a theme variable, so
   in dark mode the nav bar stayed light while the nav link text (now
   correctly turned light for the dark theme) had almost no contrast
   against it.

**Fix:** added two new semantic variables — `--text-heading` and
`--text-strong` — that the dark-mode toggle in `main.js` now flips
alongside the existing `--paper`/`--ink`/etc. Every heading and
strong-text rule in `styles.css` was repointed from raw `--navy-*`
values to these new variables (raw navy values are kept as-is for
backgrounds like buttons and hero gradients, which are meant to stay
dark in both themes). The header background and input focus background
were also moved onto theme variables. Verified with actual before/after
screenshots in both light and dark mode, plus a live interaction test
(filling in appliances and clicking Calculate) to confirm the
calculator itself still works correctly.

## Favicon

Generated a full icon set matching the site's brand mark (navy-to-teal
gradient square with the white lightning bolt used in the header and
the OG image):

- `favicon.ico` (16/32/48px, multi-size) at the site root
- `assets/icons/icon-16.png`, `icon-32.png`, `icon-192.png`, `icon-512.png`
- `assets/icons/apple-touch-icon.png` (180×180, solid background — iOS
  doesn't respect transparency on home-screen icons)
- `site.webmanifest` referencing the 192/512 icons, so the site can be
  "installed" to a phone home screen with the right name and colors

All 23 pages (including 404) link to these in `<head>`. Verified with
a live local-server request — every icon file and the manifest return
HTTP 200, and the manifest JSON parses cleanly.

## Rebrand: Barq → Clacora Tools

The site was renamed from "Barq" to "Clacora Tools" everywhere —
header, titles, meta tags, JSON-LD, footers, sitemap, and the
placeholder domain (`barq.example` → `clacora-tools.example`).

**Important — a real bug happened during this rename and was fixed:**
the site's shared JS namespace was `window.Barq` (used by every
calculator for number formatting). A blind find-and-replace of "Barq"
→ "Clacora Tools" turned that into `window.Clacora Tools` — invalid
JavaScript, because identifiers can't contain spaces. This broke
every single calculator. It's fixed now: the JS object is
`window.ClacoraTools` (no space) while all visible text says
"Clacora Tools." Re-ran the full test suite (JS syntax, JSON-LD,
div balance, broken-link check, and a live local-server load test)
after the fix — everything passes.

Also regenerated `assets/og-default.jpg` (the social-share image) with
the new name, and updated `set-domain.sh`'s default old-domain value
to `clacora-tools.example` so it keeps working for future domain
swaps. Internal `localStorage` key prefixes were also renamed
(`barq-*` → `clacora-*`) for consistency — this only resets any
previously saved calculator inputs in a browser, nothing else.

**If you ever do a find-and-replace like this yourself**, grep for
the old name inside `.js` files first — anywhere it's glued to code
(`window.Barq`, a function name, a variable) needs a no-space
version, while anywhere it's in text content, an HTML attribute
value, or a JSON string can safely take the spaced display name.

## Bug-fix pass (external audit)

An external audit flagged several real issues, now fixed:

- **Dead link removed**: `/solar/solar-battery-calculator/` was linked
  from 3 places (homepage, its footer, and the load calculator's
  related-calculators section) but the page was never built. Replaced
  those links with real, existing pages (blog articles + other
  calculators). Also removed the stale entry from `sitemap.xml`.
- **Search now actually works**: the homepage and 404 page had a
  search form pointing to `/search`, but that page didn't exist —
  it's now a real client-side search (`/search/`) that filters every
  calculator, guide and category page from `assets/js/search-index.js`.
  Add a new calculator or blog post to that file and it becomes
  searchable everywhere, no backend needed.
- **Social metadata completed**: every page was missing `og:url`,
  `og:image` and Twitter card tags (some pages were missing `og:title`
  /`og:description`/`og:type` entirely). All 22 pages now have complete
  Open Graph + Twitter Card metadata, using a generated default share
  image at `assets/og-default.jpg`.
- **Title/meta description lengths trimmed** on the worst offenders
  (some ran 80-195 characters; Google truncates well before that).
- **Placeholder domain**: `clacora-tools.example` is used deliberately — it's
  the IANA-reserved placeholder TLD, the same convention as
  `example.com`. It's consistent across all 25 files (canonical URLs,
  OG tags, JSON-LD, sitemap), so switching it is a single command:
  ```
  ./set-domain.sh yourdomain.com
  ```
  Run this once from inside the `site/` folder right before deploying.
  It rewrites every reference in one pass — tested against a full copy
  of the site.

Two flagged items are **not bugs, just current scope** — worth
knowing about, not something to "fix" by editing files:
- *"Calculator data sources weak/generalized"* — every calculator
  already states this plainly in its Methodology/Assumptions section
  (city sun-hours, crop NPK figures, feed composition, etc. are
  general planning estimates, not lab-sourced data). Real per-source
  citations would need actual research time, not a rewrite.
- *"Content quantity low"* — 5 calculators + 6 blog posts is what's
  been built so far; growing this is the ongoing roadmap below, not a
  defect.

## Aage kya banana hai

- Baaqi future-expansion calculators (Solar ROI, PSX average-price
  standalone, irrigation calculator, milk-profit calculator, compound
  interest, waghera — category pages par "Coming soon" cards ke taur
  par already list ho chuke hain, sirf inhein build karna baaqi hai)
- Keyword-mapping SEO doc (150+ keywords → page mapping — volume ke
  liye external SEO tool database chahiye hoga, is environment mein
  woh data verify nahi ho sakta)
- Test suite (zero/negative/edge-case values ke liye — abhi manual
  syntax/JSON-LD/div-balance checks kiye gaye hain, automated unit
  tests nahi)
- 404 page
- Contact form abhi `mailto:` fallback use karta hai (koi backend
  network access nahi tha is environment mein) — real deployment mein
  isko Formspree/Netlify Forms/apna backend se replace karein, aur
  har jaga `hello@clacora-tools.example` / `clacora-tools.example` domain ko apni asli
  domain aur email se badal dein (yeh sirf placeholder hai)

Agla batayen kya priority hai.
