/* ============================================================
   PSX Profit / Loss Calculator — calculation engine
   ============================================================ */
(function(){
  const fmt = window.ClacoraTools.fmt;
  const el = (id)=>document.getElementById(id);

  let buyRows = [{price:'',qty:''}];
  let sellRows = [{price:'',qty:''}];

  function renderTxTable(containerId, rows, onChange){
    const wrap = el(containerId);
    wrap.innerHTML = `
      <div class="appliance-row" style="grid-template-columns:1fr 1fr auto;font-weight:700;background:transparent;border-bottom:2px solid var(--line)">
        <div style="font-size:.76rem;color:var(--muted-2);text-transform:uppercase">Price / share</div>
        <div style="font-size:.76rem;color:var(--muted-2);text-transform:uppercase">Shares</div>
        <div></div>
      </div>
      ${rows.map((r,i)=>`
        <div class="appliance-row" style="grid-template-columns:1fr 1fr auto">
          <div><input type="number" min="0" step="0.01" data-i="${i}" data-role="price" value="${r.price}" placeholder="PKR"></div>
          <div><input type="number" min="0" step="1" data-i="${i}" data-role="qty" value="${r.qty}" placeholder="Qty"></div>
          <div><button class="btn btn-ghost btn-sm" type="button" data-remove="${i}" aria-label="Remove row">✕</button></div>
        </div>
      `).join('')}
    `;
    wrap.querySelectorAll('input').forEach(inp=>{
      inp.addEventListener('input', ()=>{
        const i = parseInt(inp.dataset.i);
        rows[i][inp.dataset.role] = inp.value;
        onChange();
      });
    });
    wrap.querySelectorAll('[data-remove]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const i = parseInt(btn.dataset.remove);
        if(rows.length>1) rows.splice(i,1);
        renderTxTable(containerId, rows, onChange);
        onChange();
      });
    });
  }

  function addRow(rows, containerId, onChange){
    rows.push({price:'',qty:''});
    renderTxTable(containerId, rows, onChange);
  }

  function totals(rows){
    let qty=0, value=0;
    rows.forEach(r=>{
      const p = parseFloat(r.price)||0, q = parseFloat(r.qty)||0;
      qty += q; value += p*q;
    });
    return {qty, value, avg: qty>0 ? value/qty : 0};
  }

  function render(){
    const buy = totals(buyRows);
    const sell = totals(sellRows);
    const brokeragePct = (parseFloat(el('brokerage').value)||0)/100;
    const otherPct = (parseFloat(el('otherCharges').value)||0)/100;
    const cgtPct = (parseFloat(el('cgt').value)||0)/100;
    const dividend = parseFloat(el('dividend').value)||0;
    const currentPrice = parseFloat(el('currentPrice').value)||0;

    if(sell.qty > buy.qty && buy.qty>0){
      el('txWarning').style.display='block';
      el('txWarning').textContent = `You've entered ${fmt(sell.qty,0)} shares sold but only ${fmt(buy.qty,0)} bought — check your transactions.`;
    } else {
      el('txWarning').style.display='none';
    }

    const brokerageBuy = buy.value*brokeragePct;
    const otherBuy = buy.value*otherPct;
    const costBasisTotal = buy.value + brokerageBuy + otherBuy;
    const avgCostPerShare = buy.qty>0 ? costBasisTotal/buy.qty : 0;

    const brokerageSell = sell.value*brokeragePct;
    const otherSell = sell.value*otherPct;
    const netProceeds = sell.value - brokerageSell - otherSell;

    const costBasisOfSold = avgCostPerShare * sell.qty;
    const capitalGain = netProceeds - costBasisOfSold;
    const cgt = capitalGain>0 ? capitalGain*cgtPct : 0;
    const netProfit = capitalGain - cgt + dividend;
    const roi = costBasisOfSold>0 ? (netProfit/costBasisOfSold)*100 : 0;
    const returnPerShare = sell.qty>0 ? netProfit/sell.qty : 0;

    const sellSideChargeRate = brokeragePct+otherPct;
    const breakeven = sellSideChargeRate<1 ? avgCostPerShare/(1-sellSideChargeRate) : avgCostPerShare;

    const remainingShares = Math.max(0, buy.qty - sell.qty);
    const portfolioValue = remainingShares*currentPrice;
    const remainingCostBasis = avgCostPerShare*remainingShares;
    const unrealizedGain = portfolioValue - remainingCostBasis;

    el('rNetProfit').textContent = fmt(netProfit,0);
    el('rNetProfit').style.color = netProfit>=0 ? '#8ff0c0' : '#ffb4b4';
    el('rROI').textContent = fmt(roi,2);
    el('rAvgBuy').textContent = fmt(buy.avg,2);
    el('rBreakeven').textContent = fmt(breakeven,2);
    el('rReturnPerShare').textContent = fmt(returnPerShare,2);
    el('rRemainingShares').textContent = fmt(remainingShares,0);

    el('breakdownBody').innerHTML = `
      <tr><td>Total shares bought</td><td class="num">${fmt(buy.qty,0)}</td></tr>
      <tr><td>Gross investment</td><td class="num">PKR ${fmt(buy.value,0)}</td></tr>
      <tr><td>Brokerage + charges on buy</td><td class="num">PKR ${fmt(brokerageBuy+otherBuy,0)}</td></tr>
      <tr><td>Total cost basis</td><td class="num">PKR ${fmt(costBasisTotal,0)}</td></tr>
      <tr><td>Average buy price / share</td><td class="num">PKR ${fmt(avgCostPerShare,2)}</td></tr>
      <tr><td>Total shares sold</td><td class="num">${fmt(sell.qty,0)}</td></tr>
      <tr><td>Gross sale value</td><td class="num">PKR ${fmt(sell.value,0)}</td></tr>
      <tr><td>Brokerage + charges on sell</td><td class="num">PKR ${fmt(brokerageSell+otherSell,0)}</td></tr>
      <tr><td>Net sale proceeds</td><td class="num">PKR ${fmt(netProceeds,0)}</td></tr>
      <tr><td>Capital gain (before CGT)</td><td class="num">PKR ${fmt(capitalGain,0)}</td></tr>
      <tr><td>Capital Gains Tax</td><td class="num">PKR ${fmt(cgt,0)}</td></tr>
      <tr><td>Dividend income</td><td class="num">PKR ${fmt(dividend,0)}</td></tr>
      <tr><td>Net profit / loss</td><td class="num">PKR ${fmt(netProfit,0)}</td></tr>
    `;

    // simple profit/loss chart
    const max = Math.max(buy.value, sell.value, Math.abs(netProfit), 1);
    el('plChart').innerHTML = `
      <div class="bar" style="height:${Math.round((buy.value/max)*130)+8}px;background:#2668b3"><span>${fmt(buy.value,0)}</span></div>
      <div class="bar" style="height:${Math.round((sell.value/max)*130)+8}px;background:#159a5c"><span>${fmt(sell.value,0)}</span></div>
      <div class="bar" style="height:${Math.round((Math.abs(netProfit)/max)*130)+8}px;background:${netProfit>=0?'#0f8a7c':'#c23b3b'}"><span>${fmt(netProfit,0)}</span></div>
    `;

    if(remainingShares>0){
      el('portfolioPanel').style.display='block';
      el('rPortfolioValue').textContent = fmt(portfolioValue,0);
      el('rUnrealized').textContent = fmt(unrealizedGain,0);
      el('rUnrealized').style.color = unrealizedGain>=0 ? 'var(--psx-600)' : 'var(--danger)';
    } else {
      el('portfolioPanel').style.display='none';
    }

    saveToStorage();
  }

  function saveToStorage(){
    try{
      const ids=['brokerage','otherCharges','cgt','dividend','currentPrice'];
      const o={}; ids.forEach(id=>{const n=el(id); if(n) o[id]=n.value;});
      o.buyRows=buyRows; o.sellRows=sellRows;
      localStorage.setItem('clacora-psx-v1', JSON.stringify(o));
    }catch(e){}
  }
  function loadFromStorage(){
    try{
      const raw = localStorage.getItem('clacora-psx-v1');
      if(!raw) return;
      const o = JSON.parse(raw);
      ['brokerage','otherCharges','cgt','dividend','currentPrice'].forEach(id=>{const n=el(id); if(n && o[id]!==undefined) n.value=o[id];});
      if(o.buyRows?.length) buyRows = o.buyRows;
      if(o.sellRows?.length) sellRows = o.sellRows;
    }catch(e){}
  }

  function resetAll(){
    localStorage.removeItem('clacora-psx-v1');
    buyRows=[{price:'',qty:''}]; sellRows=[{price:'',qty:''}];
    ['dividend','currentPrice'].forEach(id=>el(id).value='');
    renderTxTable('buyTable', buyRows, render);
    renderTxTable('sellTable', sellRows, render);
    render();
  }

  function copyResult(){
    const text = `PSX Profit/Loss (Clacora Tools):\nAvg buy price: PKR ${el('rAvgBuy').textContent}\nBreak-even sell price: PKR ${el('rBreakeven').textContent}\nNet profit/loss: PKR ${el('rNetProfit').textContent}\nROI: ${el('rROI').textContent}%`;
    navigator.clipboard?.writeText(text).then(()=>{
      const b=el('copyBtn'); const old=b.textContent; b.textContent='Copied!'; setTimeout(()=>b.textContent=old,1500);
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    loadFromStorage();
    renderTxTable('buyTable', buyRows, render);
    renderTxTable('sellTable', sellRows, render);
    el('addBuyRow').addEventListener('click', ()=>addRow(buyRows,'buyTable',render));
    el('addSellRow').addEventListener('click', ()=>addRow(sellRows,'sellTable',render));
    ['brokerage','otherCharges','cgt','dividend','currentPrice'].forEach(id=>el(id).addEventListener('input', render));
    el('resetBtn').addEventListener('click', resetAll);
    el('copyBtn').addEventListener('click', copyResult);
    el('printBtn').addEventListener('click', ()=>window.print());
    el('shareBtn').addEventListener('click', ()=>{
      navigator.clipboard?.writeText(window.location.href);
      const b=el('shareBtn'); const old=b.textContent; b.textContent='Link copied!'; setTimeout(()=>b.textContent=old,1500);
    });
    if(!buyRows[0].price){ buyRows[0]={price:100, qty:500}; renderTxTable('buyTable',buyRows,render); }
    if(!sellRows[0].price){ sellRows[0]={price:115, qty:500}; renderTxTable('sellTable',sellRows,render); }
    render();
  });
})();
