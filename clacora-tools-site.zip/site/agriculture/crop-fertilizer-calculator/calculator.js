/* ============================================================
   Crop Fertilizer Calculator — calculation engine
   ============================================================ */
(function(){
  const fmt = window.ClacoraTools.fmt;
  const el = (id)=>document.getElementById(id);

  // General agronomic recommendations — kg of nutrient per ACRE, at average
  // yield target. Nitrogen (N), Phosphorus (as P2O5), Potassium (as K2O).
  // These are broad extension-service style figures, not a substitute for
  // a soil test — see disclaimer on the page.
  const CROPS = {
    wheat:    {label:'Wheat',    n:110, p:85, k:60,  avgYield:1.1, yieldUnit:'tons/acre'},
    rice:     {label:'Rice (transplanted)', n:100, p:60, k:50, avgYield:1.0, yieldUnit:'tons/acre'},
    maize:    {label:'Maize',    n:125, p:85, k:60,  avgYield:1.4, yieldUnit:'tons/acre'},
    cotton:   {label:'Cotton',   n:100, p:60, k:50,  avgYield:0.9, yieldUnit:'tons/acre (seed cotton)'},
    sugarcane:{label:'Sugarcane',n:170, p:85, k:85,  avgYield:25,  yieldUnit:'tons/acre'},
    potato:   {label:'Potato',   n:120, p:90, k:100, avgYield:8,   yieldUnit:'tons/acre'},
    tomato:   {label:'Tomato',   n:100, p:80, k:100, avgYield:9,   yieldUnit:'tons/acre'},
    onion:    {label:'Onion',    n:80,  p:60, k:60,  avgYield:6,   yieldUnit:'tons/acre'},
    chili:    {label:'Chili',    n:90,  p:60, k:60,  avgYield:1.2, yieldUnit:'tons/acre (dry)'},
    soybean:  {label:'Soybean',  n:25,  p:60, k:40,  avgYield:0.7, yieldUnit:'tons/acre'} // legume: low N
  };

  // Area unit → acre conversion factors
  const AREA_TO_ACRE = {
    acre:1, hectare:2.4711, kanal:0.125, marla:0.00625, sqm:0.000247105
  };

  // Soil-type efficiency adjustment — light soils leach nutrients faster,
  // heavy soils fix more phosphorus, so a broad correction factor is applied.
  const SOIL_FACTOR = { light:1.15, medium:1.0, heavy:0.9 };

  // Fertilizer nutrient content (%), standard Pakistan market products
  const FERT = {
    urea:{n:0.46, p:0, k:0, label:'Urea (46-0-0)'},
    dap: {n:0.18, p:0.46, k:0, label:'DAP (18-46-0)'},
    ssp: {n:0, p:0.18, k:0, label:'SSP (0-18-0)'},
    sop: {n:0, p:0, k:0.50, label:'SOP (0-0-50)'},
    mop: {n:0, p:0, k:0.60, label:'MOP (0-0-60)'}
  };

  function computeArea(){
    const val = parseFloat(el('fieldArea').value) || 0;
    const unit = el('areaUnit').value;
    return val * (AREA_TO_ACRE[unit]||1);
  }

  function render(){
    const cropKey = el('crop').value;
    const crop = CROPS[cropKey];
    const acres = computeArea();
    const soilFactor = SOIL_FACTOR[el('soilType').value] || 1;
    const targetYield = parseFloat(el('targetYield').value);
    const yieldFactor = (targetYield && crop.avgYield) ? Math.max(0.5, Math.min(2, targetYield/crop.avgYield)) : 1;

    if(acres<=0){
      el('cropValidation').style.display='block';
      return;
    }
    el('cropValidation').style.display='none';

    const nNeeded = crop.n * acres * soilFactor * yieldFactor;
    const pNeeded = crop.p * acres * soilFactor * yieldFactor;
    const kNeeded = crop.k * acres * soilFactor * yieldFactor;

    // Phosphorus source first (also credits some N), then top up N with urea, then K.
    const pSourceKey = el('pSource').value;
    const kSourceKey = el('kSource').value;
    const pSource = FERT[pSourceKey];
    const kSource = FERT[kSourceKey];

    const pSourceKg = pSource.p>0 ? pNeeded / pSource.p : 0;
    const nCreditFromP = pSourceKg * pSource.n;
    const remainingN = Math.max(0, nNeeded - nCreditFromP);
    const ureaKg = remainingN / FERT.urea.n;
    const kSourceKg = kSource.k>0 ? kNeeded / kSource.k : 0;

    const bagsOf = (kg)=> kg/50;

    // Cost
    const ureaRate = parseFloat(el('ureaRate').value)||0;
    const pRate = parseFloat(el('pRate').value)||0;
    const kRate = parseFloat(el('kRate').value)||0;
    const cost = bagsOf(ureaKg)*ureaRate + bagsOf(pSourceKg)*pRate + bagsOf(kSourceKg)*kRate;

    // Splits for N
    const splits = parseInt(el('nSplits').value)||2;
    const perSplit = ureaKg/splits;

    el('rN').textContent = fmt(nNeeded,1);
    el('rP').textContent = fmt(pNeeded,1);
    el('rK').textContent = fmt(kNeeded,1);
    el('rAcres').textContent = fmt(acres,2);
    el('rCost').textContent = fmt(cost,0);

    el('breakdownBody').innerHTML = `
      <tr><td>Field area (converted)</td><td class="num">${fmt(acres,2)} acre</td></tr>
      <tr><td>Nitrogen (N) required</td><td class="num">${fmt(nNeeded,1)} kg</td></tr>
      <tr><td>Phosphorus (P₂O₅) required</td><td class="num">${fmt(pNeeded,1)} kg</td></tr>
      <tr><td>Potassium (K₂O) required</td><td class="num">${fmt(kNeeded,1)} kg</td></tr>
      <tr><td>${FERT[pSourceKey].label} needed</td><td class="num">${fmt(pSourceKg,1)} kg (${fmt(bagsOf(pSourceKg),1)} bags)</td></tr>
      <tr><td>Urea needed (after N credit from ${FERT[pSourceKey].label})</td><td class="num">${fmt(ureaKg,1)} kg (${fmt(bagsOf(ureaKg),1)} bags)</td></tr>
      <tr><td>${FERT[kSourceKey].label} needed</td><td class="num">${fmt(kSourceKg,1)} kg (${fmt(bagsOf(kSourceKg),1)} bags)</td></tr>
      <tr><td>Estimated total cost</td><td class="num">PKR ${fmt(cost,0)}</td></tr>
    `;

    el('splitPlan').innerHTML = `
      <li>${FERT[pSourceKey].label} (${fmt(bagsOf(pSourceKg),1)} bags) and ${FERT[kSourceKey].label} (${fmt(bagsOf(kSourceKg),1)} bags): apply full dose at sowing/basal.</li>
      <li>Urea (${fmt(bagsOf(ureaKg),1)} bags total): split into ${splits} equal doses of ≈ ${fmt(perSplit,1)} kg (${fmt(bagsOf(perSplit),1)} bags) each — first at sowing/basal, remaining at key growth stages (e.g. tillering, stem elongation).</li>
    `;

    el('yieldNote').textContent = `Average reference yield for ${crop.label}: ${crop.avgYield} ${crop.yieldUnit}. ${targetYield ? 'Your target yield scaled the requirement by ' + fmt(yieldFactor*100,0) + '% of the base recommendation.' : 'Enter a target yield above to scale the recommendation up or down.'}`;

    // simple visual bar for N/P/K
    const max = Math.max(nNeeded,pNeeded,kNeeded,1);
    el('npkChart').innerHTML = `
      <div class="bar" style="height:${Math.round((nNeeded/max)*130)+8}px;background:#5f9a3b"><span>${fmt(nNeeded,0)}</span></div>
      <div class="bar" style="height:${Math.round((pNeeded/max)*130)+8}px;background:#4a7a2e"><span>${fmt(pNeeded,0)}</span></div>
      <div class="bar" style="height:${Math.round((kNeeded/max)*130)+8}px;background:#8a5a1f"><span>${fmt(kNeeded,0)}</span></div>
    `;
    saveToStorage();
  }

  function saveToStorage(){
    try{
      const ids = ['crop','fieldArea','areaUnit','soilType','targetYield','pSource','kSource','ureaRate','pRate','kRate','nSplits'];
      const o={}; ids.forEach(id=>{const n=el(id); if(n) o[id]=n.value;});
      localStorage.setItem('clacora-fertilizer-v1', JSON.stringify(o));
    }catch(e){}
  }
  function loadFromStorage(){
    try{
      const raw = localStorage.getItem('clacora-fertilizer-v1');
      if(!raw) return;
      const o = JSON.parse(raw);
      Object.keys(o).forEach(id=>{const n=el(id); if(n) n.value=o[id];});
    }catch(e){}
  }

  function reset(){
    localStorage.removeItem('clacora-fertilizer-v1');
    ['fieldArea','targetYield'].forEach(id=>el(id).value='');
    render();
  }

  function copyResult(){
    const text = `Crop Fertilizer Calculator (Clacora Tools):\nCrop: ${el('crop').selectedOptions[0].textContent}\nArea: ${el('rAcres').textContent} acre\nN: ${el('rN').textContent} kg · P₂O₅: ${el('rP').textContent} kg · K₂O: ${el('rK').textContent} kg\nEstimated cost: PKR ${el('rCost').textContent}`;
    navigator.clipboard?.writeText(text).then(()=>{
      const b=el('copyBtn'); const old=b.textContent; b.textContent='Copied!'; setTimeout(()=>b.textContent=old,1500);
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    loadFromStorage();
    el('calcBtn').addEventListener('click', render);
    el('resetBtn').addEventListener('click', reset);
    el('copyBtn').addEventListener('click', copyResult);
    el('printBtn').addEventListener('click', ()=>window.print());
    el('shareBtn').addEventListener('click', ()=>{
      navigator.clipboard?.writeText(window.location.href);
      const b=el('shareBtn'); const old=b.textContent; b.textContent='Link copied!'; setTimeout(()=>b.textContent=old,1500);
    });
    if(!el('fieldArea').value) el('fieldArea').value = 5;
    render();
  });
})();
