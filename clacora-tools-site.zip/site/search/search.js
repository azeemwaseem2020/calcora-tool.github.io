(function(){
  const el = (id)=>document.getElementById(id);

  function score(item, terms){
    const hay = (item.title+' '+item.desc+' '+item.category+' '+item.keywords).toLowerCase();
    let s = 0;
    terms.forEach(t=>{
      if(!t) return;
      if(item.title.toLowerCase().includes(t)) s += 5;
      if(hay.includes(t)) s += 1;
    });
    return s;
  }

  function typeColor(type){
    return {Calculator:'var(--teal-600)', Guide:'var(--solar-600)', Category:'var(--loan-600)'}[type] || 'var(--muted-2)';
  }

  function render(query){
    const results = el('results');
    const heading = el('resultHeading');
    const q = (query||'').trim().toLowerCase();

    if(!q){
      heading.textContent = 'Popular calculators';
      const popular = ['/solar/solar-load-calculator/','/finance/loan-emi-calculator/','/psx/psx-profit-loss-calculator/','/agriculture/crop-fertilizer-calculator/','/livestock/tmr-calculator/'];
      const items = window.CLACORA_SEARCH_INDEX.filter(i=>popular.includes(i.url));
      renderList(items);
      return;
    }

    const terms = q.split(/\s+/).filter(Boolean);
    const scored = window.CLACORA_SEARCH_INDEX
      .map(item=>({item, s:score(item, terms)}))
      .filter(x=>x.s>0)
      .sort((a,b)=>b.s-a.s)
      .map(x=>x.item);

    heading.textContent = scored.length
      ? `${scored.length} result${scored.length>1?'s':''} for "${query}"`
      : `No results for "${query}"`;
    renderList(scored);
  }

  function renderList(items){
    const results = el('results');
    if(!items.length){
      results.innerHTML = `<p class="sub">Try a different word, or browse a category from the menu above.</p>`;
      return;
    }
    results.innerHTML = items.map(item=>`
      <a class="calc-card" href="${item.url}">
        <span class="tag" style="color:${typeColor(item.type)}">${item.type} · ${item.category}</span>
        <h3>${item.title}</h3>
        <p>${item.desc}</p>
        <span class="go">Open →</span>
      </a>
    `).join('');
  }

  document.addEventListener('DOMContentLoaded', function(){
    const params = new URLSearchParams(window.location.search);
    const q = params.get('q') || '';
    el('searchInput').value = q;
    render(q);

    el('searchForm').addEventListener('submit', function(e){
      e.preventDefault();
      const val = el('searchInput').value;
      const url = new URL(window.location.href);
      if(val) url.searchParams.set('q', val); else url.searchParams.delete('q');
      window.history.replaceState({}, '', url);
      render(val);
    });

    el('searchInput').addEventListener('input', function(){
      render(this.value);
    });
  });
})();
