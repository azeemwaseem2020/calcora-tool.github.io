/* ============================================================
   Solar Load & Battery Calculator — calculation engine
   All math runs client-side. No input ever leaves the browser.
   ============================================================ */
(function(){
  const fmt = window.ClacoraTools.fmt;

  /* ---------------- Reference data (clearly labelled, editable) ---------------- */

  // Average daily peak sun hours — Pakistan cities (approximate annual average).
  // Source: typical NASA POWER / PVGIS ranges for the region. Treat as an estimate;
  // a real installer should confirm with local irradiance data before final sizing.
  const CITY_SUN_HOURS = {
    'karachi': 5.6, 'lahore': 5.2, 'islamabad': 5.0, 'faisalabad': 5.3,
    'rawalpindi': 5.0, 'multan': 5.4, 'peshawar': 5.1, 'quetta': 5.7,
    'hyderabad': 5.6, 'sialkot': 5.0, 'gujranwala': 5.1, 'sukkur': 5.6,
    'other': 5.0
  };

  const APPLIANCES = [
    // category, name, default watt
    {cat:'cooling', name:'Split AC – 1 Ton (Inverter)', w:1000},
    {cat:'cooling', name:'Split AC – 1.5 Ton (Inverter)', w:1500},
    {cat:'cooling', name:'Split AC – 1.5 Ton (Non-inverter)', w:1800},
    {cat:'cooling', name:'Split AC – 2 Ton', w:2600},
    {cat:'cooling', name:'Air cooler', w:200},
    {cat:'fans', name:'Ceiling fan', w:75},
    {cat:'fans', name:'Pedestal / stand fan', w:60},
    {cat:'fans', name:'Exhaust fan', w:40},
    {cat:'lighting', name:'LED bulb (9W)', w:9},
    {cat:'lighting', name:'LED tube light (20W)', w:20},
    {cat:'lighting', name:'Energy saver bulb', w:23},
    {cat:'kitchen', name:'Refrigerator (medium)', w:150},
    {cat:'kitchen', name:'Deep freezer', w:250},
    {cat:'kitchen', name:'Microwave oven', w:1200},
    {cat:'kitchen', name:'Electric kettle', w:1500},
    {cat:'kitchen', name:'Blender / mixer', w:400},
    {cat:'electronics', name:'LED TV (40")', w:80},
    {cat:'electronics', name:'Desktop computer', w:200},
    {cat:'electronics', name:'Laptop', w:65},
    {cat:'electronics', name:'Wi-Fi router', w:12},
    {cat:'electronics', name:'Phone charger', w:10},
    {cat:'water', name:'Water pump (0.5 HP)', w:370},
    {cat:'water', name:'Water pump (1 HP)', w:750},
    {cat:'water', name:'Motor pump (1.5 HP)', w:1100},
    {cat:'office', name:'Printer', w:350},
    {cat:'office', name:'Photocopier', w:1200},
    {cat:'pumps', name:'Submersible pump (small)', w:550},
    {cat:'pumps', name:'Tube well motor', w:2200},
  ];

  const CATEGORY_LABEL = {
    cooling:'Cooling', fans:'Fans', lighting:'Lighting', kitchen:'Kitchen',
    electronics:'Electronics', water:'Water', office:'Office', pumps:'Pumps'
  };

  // Depth of discharge & round-trip efficiency assumptions by battery chemistry.
  const BATTERY_PROFILE = {
    lithium:   {dod:0.90, label:'Lithium (LiFePO4)'},
    'lead-acid': {dod:0.50, label:'Lead-acid (flooded/tubular)'},
    agm:       {dod:0.60, label:'AGM / Sealed'},
    gel:       {dod:0.60, label:'Gel'}
  };

  const STANDARD_INVERTER_SIZES = [800,1000,1500,2000,3000,3500,5000,7500,10000,12000];

  /* ---------------- State ---------------- */
  let selected = {}; // name -> {watt, qty, hours}
  let activeTab = 'cooling';

  /* ---------------- DOM refs ---------------- */
  const el = (id)=>document.getElementById(id);

  function buildTabs(){
    const wrap = el('applianceTabs');
    const cats = Object.keys(CATEGORY_LABEL);
    wrap.innerHTML = cats.map(c=>`<button data-cat="${c}" class="${c===activeTab?'active':''}" type="button">${CATEGORY_LABEL[c]}</button>`).join('');
    wrap.querySelectorAll('button').forEach(btn=>{
      btn.addEventListener('click', ()=>{ activeTab = btn.dataset.cat; buildTabs(); buildList(); });
    });
  }

  function buildList(){
    const wrap = el('applianceList');
    const items = APPLIANCES.filter(a=>a.cat===activeTab);
    wrap.innerHTML = items.map(a=>{
      const s = selected[a.name] || {qty:0, hours:0};
      return `
      <div class="appliance-row">
        <div>
          <div class="name">${a.name}</div>
          <div class="w">${a.w} W each</div>
        </div>
        <div><input type="number" min="0" step="1" data-role="qty" data-name="${a.name}" data-watt="${a.w}" value="${s.qty||''}" placeholder="Qty" aria-label="Quantity of ${a.name}"></div>
        <div style="color:var(--muted-2);font-size:.78rem">hrs/day</div>
        <div><input type="number" min="0" max="24" step="0.5" data-role="hours" data-name="${a.name}" value="${s.hours||''}" placeholder="0" aria-label="Hours per day for ${a.name}"></div>
      </div>`;
    }).join('');

    wrap.querySelectorAll('input').forEach(inp=>{
      inp.addEventListener('input', onApplianceInput);
    });
  }

  function onApplianceInput(e){
    const name = e.target.dataset.name;
    const role = e.target.dataset.role;
    const val = parseFloat(e.target.value) || 0;
    if(!selected[name]) selected[name] = {qty:0, hours:0, watt: parseFloat(e.target.dataset.watt)||0};
    if(role==='qty') selected[name].qty = val;
    if(role==='hours') selected[name].hours = val;
    if(e.target.dataset.watt) selected[name].watt = parseFloat(e.target.dataset.watt);
    updateApplianceSummary();
  }

  function addCustomAppliance(){
    const name = el('customName').value.trim();
    const watt = parseFloat(el('customWatt').value);
    const qty = parseFloat(el('customQty').value) || 1;
    const hours = parseFloat(el('customHours').value) || 0;
    if(!name || !watt || watt<=0){
      el('customError').style.display='block';
      return;
    }
    el('customError').style.display='none';
    selected[name] = {qty, hours, watt, custom:true};
    APPLIANCES.push({cat:'electronics', name, w:watt});
    el('customName').value=''; el('customWatt').value=''; el('customQty').value=''; el('customHours').value='';
    activeTab='electronics';
    buildTabs(); buildList(); updateApplianceSummary();
  }

  function selectedList(){
    return Object.keys(selected).map(name=>({name, ...selected[name]})).filter(a=>a.qty>0);
  }

  function updateApplianceSummary(){
    const items = selectedList();
    const connected = items.reduce((s,a)=>s+a.watt*a.qty,0);
    const dailyWh = items.reduce((s,a)=>s+a.watt*a.qty*a.hours,0);
    el('applianceSummary').textContent =
      items.length
        ? `${items.length} appliance type(s) selected · Connected load ${fmt(connected)} W · Daily energy ${fmt(dailyWh/1000,2)} kWh`
        : 'No appliances selected yet — pick items above, or switch to "By electricity bill" mode.';
  }

  /* ---------------- Mode toggle: appliances vs bill ---------------- */
  function setMode(mode){
    document.querySelectorAll('.seg-mode button').forEach(b=>b.classList.toggle('active', b.dataset.mode===mode));
    el('applianceModePanel').style.display = mode==='appliances' ? 'block':'none';
    el('billModePanel').style.display = mode==='bill' ? 'block':'none';
    el('inputMode').value = mode;
  }

  /* ---------------- System type toggle ---------------- */
  function setSystemType(type){
    document.querySelectorAll('.seg-system button').forEach(b=>b.classList.toggle('active', b.dataset.type===type));
    el('systemType').value = type;
    el('backupField').style.display = type==='on-grid' ? 'none' : 'flex';
  }

  /* ---------------- Core calculation ---------------- */
  function nearestInverterSize(watts){
    for(const s of STANDARD_INVERTER_SIZES){ if(s>=watts) return s; }
    return STANDARD_INVERTER_SIZES[STANDARD_INVERTER_SIZES.length-1];
  }

  function computeCore(scaleFactor){
    const mode = el('inputMode').value;
    const city = el('city').value;
    const sunHours = CITY_SUN_HOURS[city] ?? 5.0;
    const systemType = el('systemType').value;
    const backupHours = parseFloat(el('backupHours').value) || 4;
    const panelWatt = parseFloat(el('panelWatt').value) || 550;
    const batteryType = el('batteryType').value;
    const batteryVoltage = parseFloat(el('batteryVoltage').value) || 12;
    const inverterEff = (parseFloat(el('inverterEff').value) || 90) / 100;
    const sysLossPct = (parseFloat(el('sysLoss').value) || 15) / 100;
    const diversity = 0.8; // realistic simultaneous-use factor (assumption)
    const surgeFactor = 1.3; // starting-surge allowance for motors/AC/fans

    let connectedLoad, dailyKWh;

    if(mode === 'appliances'){
      const items = selectedList();
      connectedLoad = items.reduce((s,a)=>s+a.watt*a.qty,0);
      dailyKWh = items.reduce((s,a)=>s+a.watt*a.qty*a.hours,0) / 1000;
    } else {
      const bill = parseFloat(el('billAmount').value) || 0;
      const units = parseFloat(el('billUnits').value) || 0;
      if(units > 0){
        dailyKWh = units / 30;
      } else {
        // rough Pakistan residential tariff assumption for bill→units conversion
        const avgRate = parseFloat(el('unitPrice').value) || 45;
        dailyKWh = (bill / avgRate) / 30;
      }
      connectedLoad = (dailyKWh*1000) / 6; // rough assumed avg daily usage window
    }

    connectedLoad *= scaleFactor;
    dailyKWh *= scaleFactor;

    const runningLoad = connectedLoad * diversity;
    const peakLoad = runningLoad * surgeFactor;
    const monthlyKWh = dailyKWh * 30;

    const overallEff = inverterEff * (1 - sysLossPct);
    const recommendedKW = overallEff>0 ? dailyKWh / (sunHours * overallEff) : 0;
    const panelCount = panelWatt>0 ? Math.ceil((recommendedKW*1000) / panelWatt) : 0;

    let batteryKWh = 0, batteryAh = 0, inverterSize = 0, backupTimeEstimate = backupHours;
    if(systemType !== 'on-grid'){
      const dod = BATTERY_PROFILE[batteryType]?.dod || 0.6;
      const backupEnergyWh = runningLoad * backupHours;
      batteryKWh = dod>0 ? (backupEnergyWh / dod) / 1000 / inverterEff : 0;
      batteryAh = batteryVoltage>0 ? (batteryKWh*1000) / batteryVoltage : 0;
      inverterSize = nearestInverterSize(peakLoad * 1.1);
    } else {
      inverterSize = nearestInverterSize(peakLoad);
    }

    // Cost & payback (editable assumptions)
    const panelRate = parseFloat(el('panelRate').value) || 45;      // PKR / W
    const batteryRate = parseFloat(el('batteryRate').value) || 35000; // PKR / usable kWh
    const inverterRate = parseFloat(el('inverterRate').value) || 22; // PKR / W
    const unitPrice = parseFloat(el('unitPrice').value) || 45;      // PKR / unit

    const panelCost = recommendedKW*1000*panelRate;
    const batteryCost = batteryKWh*batteryRate;
    const inverterCost = inverterSize*inverterRate;
    const installMisc = (panelCost+batteryCost+inverterCost)*0.12; // wiring/structure/labour assumption
    const totalCost = panelCost+batteryCost+inverterCost+installMisc;

    const monthlySavings = monthlyKWh*unitPrice;
    const paybackYears = monthlySavings>0 ? totalCost/(monthlySavings*12) : null;

    return {
      connectedLoad, runningLoad, peakLoad, dailyKWh, monthlyKWh,
      recommendedKW, panelCount, batteryKWh, batteryAh, inverterSize,
      backupTimeEstimate, panelCost, batteryCost, inverterCost, installMisc, totalCost,
      monthlySavings, paybackYears, sunHours
    };
  }

  /* ---------------- Rendering ---------------- */
  function renderChart(items){
    const chart = el('energyChart');
    const labelsEl = el('energyChartLabels');
    if(!items.length){ chart.innerHTML=''; labelsEl.innerHTML=''; return; }
    const byCat = {};
    items.forEach(a=>{
      const catDef = APPLIANCES.find(x=>x.name===a.name);
      const cat = catDef ? catDef.cat : 'electronics';
      byCat[cat] = (byCat[cat]||0) + a.watt*a.qty*a.hours;
    });
    const max = Math.max(...Object.values(byCat), 1);
    const colors = {cooling:'#e88a12',fans:'#2668b3',lighting:'#e8b312',kitchen:'#c23b3b',electronics:'#5f9a3b',water:'#159a5c',office:'#8a5a1f',pumps:'#0f8a7c'};
    chart.innerHTML = Object.keys(byCat).map(cat=>{
      const h = Math.round((byCat[cat]/max)*130)+8;
      return `<div class="bar" style="height:${h}px;background:${colors[cat]||'#28407c'}"><span>${fmt(byCat[cat]/1000,1)}kWh</span></div>`;
    }).join('');
    labelsEl.innerHTML = Object.keys(byCat).map(cat=>`<div>${CATEGORY_LABEL[cat]}</div>`).join('');
  }

  function render(){
    const items = selectedList();
    const base = computeCore(1);

    // headline result
    el('rHeadline').textContent = fmt(base.recommendedKW,2);
    el('rDaily').textContent = fmt(base.dailyKWh,1);
    el('rMonthly').textContent = fmt(base.monthlyKWh,0);
    el('rPanels').textContent = fmt(base.panelCount,0);
    el('rBattery').textContent = base.batteryKWh ? fmt(base.batteryKWh,2)+' kWh' : '—';
    el('rBatteryAh').textContent = base.batteryAh ? fmt(base.batteryAh,0)+' Ah' : '—';
    el('rInverter').textContent = fmt(base.inverterSize,0);
    el('rPayback').textContent = base.paybackYears ? fmt(base.paybackYears,1)+' yrs' : '—';

    // breakdown table
    el('breakdownBody').innerHTML = `
      <tr><td>Connected load</td><td class="num">${fmt(base.connectedLoad,0)} W</td></tr>
      <tr><td>Diversified running load</td><td class="num">${fmt(base.runningLoad,0)} W</td></tr>
      <tr><td>Peak load (with starting surge)</td><td class="num">${fmt(base.peakLoad,0)} W</td></tr>
      <tr><td>Daily energy consumption</td><td class="num">${fmt(base.dailyKWh,2)} kWh</td></tr>
      <tr><td>Monthly energy consumption</td><td class="num">${fmt(base.monthlyKWh,0)} kWh</td></tr>
      <tr><td>Peak sun hours used (${el('city').selectedOptions[0]?.textContent||''})</td><td class="num">${fmt(base.sunHours,1)} hrs</td></tr>
      <tr><td>Estimated system cost</td><td class="num">PKR ${fmt(base.totalCost,0)}</td></tr>
    `;

    // scenarios
    const cons = computeCore(0.8);
    const high = computeCore(1.25);
    const scenarios = [
      {name:'Conservative', d:cons, note:'Lower budget, tighter backup margin'},
      {name:'Recommended', d:base, note:'Balanced sizing for typical daily use', reco:true},
      {name:'High-demand', d:high, note:'Extra headroom for future load growth'}
    ];
    el('scenarioGrid').innerHTML = scenarios.map(s=>`
      <div class="scenario-card ${s.reco?'reco':''}">
        <div class="name">${s.name}</div>
        <div class="val">${fmt(s.d.recommendedKW,2)} kW</div>
        <ul>
          <li>${fmt(s.d.panelCount,0)} panels (${el('panelWatt').value}W)</li>
          <li>${s.d.batteryKWh ? fmt(s.d.batteryKWh,1)+' kWh battery' : 'On-grid — no battery'}</li>
          <li>${fmt(s.d.inverterSize,0)} W inverter</li>
          <li>≈ PKR ${fmt(s.d.totalCost,0)}</li>
        </ul>
      </div>
    `).join('');

    renderChart(items);
    updateApplianceSummary();
    saveToStorage();
  }

  /* ---------------- Persistence / share / copy / print ---------------- */
  function saveToStorage(){
    try{
      localStorage.setItem('clacora-solar-load-v1', JSON.stringify({selected, inputs: gatherInputs()}));
    }catch(e){/* storage unavailable — ignore silently */}
  }
  function gatherInputs(){
    const ids = ['city','systemType','backupHours','panelWatt','batteryType','batteryVoltage','inverterEff','sysLoss','billAmount','billUnits','unitPrice','panelRate','batteryRate','inverterRate','inputMode'];
    const o = {};
    ids.forEach(id=>{ const n=el(id); if(n) o[id]=n.value; });
    return o;
  }
  function loadFromStorage(){
    try{
      const raw = localStorage.getItem('clacora-solar-load-v1');
      if(!raw) return;
      const data = JSON.parse(raw);
      selected = data.selected || {};
      Object.keys(data.inputs||{}).forEach(id=>{ const n=el(id); if(n) n.value = data.inputs[id]; });
    }catch(e){/* ignore corrupt storage */}
  }

  function copyResult(){
    const base = computeCore(1);
    const text = `Solar system estimate (Clacora Tools):\n`+
      `Recommended system: ${fmt(base.recommendedKW,2)} kW\n`+
      `Panels: ${fmt(base.panelCount,0)} × ${el('panelWatt').value}W\n`+
      `Battery: ${base.batteryKWh?fmt(base.batteryKWh,2)+' kWh':'—'}\n`+
      `Inverter: ${fmt(base.inverterSize,0)} W\n`+
      `Estimated cost: PKR ${fmt(base.totalCost,0)}`;
    navigator.clipboard?.writeText(text).then(()=>{
      const b = el('copyBtn'); const old = b.textContent; b.textContent='Copied!'; setTimeout(()=>b.textContent=old,1500);
    });
  }

  function resetAll(){
    selected = {};
    localStorage.removeItem('clacora-solar-load-v1');
    document.querySelectorAll('input[type=number], input[type=text]').forEach(i=>{ if(!i.readOnly) i.value=''; });
    buildTabs(); buildList(); render();
  }

  function validateAndRun(){
    let ok = true;
    if(el('inputMode').value==='appliances' && selectedList().length===0){
      el('applianceValidation').style.display='block';
      ok = false;
    } else {
      el('applianceValidation').style.display='none';
    }
    if(ok) render();
    return ok;
  }

  /* ---------------- Init ---------------- */
  document.addEventListener('DOMContentLoaded', function(){
    buildTabs();
    buildList();
    loadFromStorage();

    document.querySelectorAll('.seg-mode button').forEach(b=>b.addEventListener('click', ()=>setMode(b.dataset.mode)));
    document.querySelectorAll('.seg-system button').forEach(b=>b.addEventListener('click', ()=>setSystemType(b.dataset.type)));
    el('addCustomBtn').addEventListener('click', addCustomAppliance);
    el('calcBtn').addEventListener('click', validateAndRun);
    el('resetBtn').addEventListener('click', resetAll);
    el('copyBtn').addEventListener('click', copyResult);
    el('printBtn').addEventListener('click', ()=>window.print());
    el('shareBtn').addEventListener('click', ()=>{
      navigator.clipboard?.writeText(window.location.href);
      const b = el('shareBtn'); const old=b.textContent; b.textContent='Link copied!'; setTimeout(()=>b.textContent=old,1500);
    });

    setMode('appliances');
    setSystemType('hybrid');
    validateAndRun();
  });
})();
