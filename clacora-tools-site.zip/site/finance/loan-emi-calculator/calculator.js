/* ============================================================
   Loan EMI & Amortization Calculator — calculation engine
   ============================================================ */
(function(){
  const fmt = window.ClacoraTools.fmt;
  const el = (id)=>document.getElementById(id);

  const PERIODS_PER_YEAR = {monthly:12, biweekly:26, weekly:52, yearly:1};
  const PERIOD_LABEL = {monthly:'month', biweekly:'2 weeks', weekly:'week', yearly:'year'};

  function emiFor(principal, annualRatePct, years, freq){
    const ppy = PERIODS_PER_YEAR[freq];
    const n = Math.round(years*ppy);
    const r = (annualRatePct/100)/ppy;
    const emi = r>0 ? principal*r*Math.pow(1+r,n) / (Math.pow(1+r,n)-1) : principal/n;
    return {emi, n, r, ppy};
  }

  function buildSchedule(principal, r, n, emi, extra){
    const rows = [];
    let balance = principal;
    let totalInterest = 0;
    for(let p=1; p<=n && balance>0.5; p++){
      const interest = balance*r;
      let principalPaid = emi - interest + (extra||0);
      if(principalPaid > balance) principalPaid = balance;
      balance = Math.max(0, balance - principalPaid);
      totalInterest += interest;
      rows.push({period:p, interest, principalPaid, balance});
      if(balance<=0.5) break;
    }
    return {rows, totalInterest, actualPeriods: rows.length};
  }

  function yearlySummary(rows, ppy){
    const years = [];
    for(let i=0;i<rows.length;i+=ppy){
      const chunk = rows.slice(i, i+ppy);
      years.push({
        year: years.length+1,
        principal: chunk.reduce((s,r)=>s+r.principalPaid,0),
        interest: chunk.reduce((s,r)=>s+r.interest,0),
        endBalance: chunk[chunk.length-1].balance
      });
    }
    return years;
  }

  function computeLoan(prefix){
    const amount = parseFloat(el(prefix+'Amount').value)||0;
    const down = parseFloat(el(prefix+'Down')?.value)||0;
    const rate = parseFloat(el(prefix+'Rate').value)||0;
    const years = parseFloat(el(prefix+'Years').value)||0;
    const freq = el(prefix+'Freq') ? el(prefix+'Freq').value : el('freq').value;
    const financed = Math.max(0, amount-down);
    const {emi, n, r, ppy} = emiFor(financed, rate, years, freq);
    const base = buildSchedule(financed, r, n, emi, 0);
    return {amount, down, rate, years, freq, financed, emi, n, r, ppy, base};
  }

  function render(){
    const fees = parseFloat(el('fees').value)||0;
    const extra = parseFloat(el('extraPayment').value)||0;
    const loan = computeLoan('');
    const totalPaymentBase = loan.emi*loan.n;

    const withExtra = extra>0 ? buildSchedule(loan.financed, loan.r, loan.n, loan.emi, extra) : loan.base;
    const interestSaved = loan.base.totalInterest - withExtra.totalInterest;
    const timeSavedPeriods = loan.base.rows.length - withExtra.rows.length;

    el('rEMI').textContent = fmt(loan.emi,0);
    el('rFreqLabel').textContent = 'per ' + PERIOD_LABEL[loan.freq];
    el('rTotalInterest').textContent = fmt(withExtra.totalInterest,0);
    el('rTotalPayment').textContent = fmt(loan.financed + withExtra.totalInterest,0);
    el('rPayoffPeriods').textContent = fmt(withExtra.rows.length,0) + ' ' + PERIOD_LABEL[loan.freq] + 's';
    el('rFeesNote').textContent = fees>0 ? `Plus PKR ${fmt(fees,0)} one-time fees (not amortized).` : '';

    if(extra>0){
      el('extraSavings').style.display='block';
      el('rInterestSaved').textContent = fmt(interestSaved,0);
      el('rTimeSaved').textContent = fmt(timeSavedPeriods,0) + ' ' + PERIOD_LABEL[loan.freq] + 's';
    } else {
      el('extraSavings').style.display='none';
    }

    el('breakdownBody').innerHTML = `
      <tr><td>Amount financed</td><td class="num">PKR ${fmt(loan.financed,0)}</td></tr>
      <tr><td>Interest rate</td><td class="num">${fmt(loan.rate,2)}% / year</td></tr>
      <tr><td>Term</td><td class="num">${fmt(loan.years,1)} years (${loan.n} ${PERIOD_LABEL[loan.freq]}s)</td></tr>
      <tr><td>Payment per ${PERIOD_LABEL[loan.freq]}</td><td class="num">PKR ${fmt(loan.emi,0)}</td></tr>
      <tr><td>Total interest</td><td class="num">PKR ${fmt(withExtra.totalInterest,0)}</td></tr>
      <tr><td>Total of all payments</td><td class="num">PKR ${fmt(loan.financed+withExtra.totalInterest,0)}</td></tr>
    `;

    // yearly summary + chart
    const years = yearlySummary(withExtra.rows, loan.ppy);
    el('yearlyBody').innerHTML = years.map(y=>`
      <tr><td>Year ${y.year}</td><td class="num">${fmt(y.principal,0)}</td><td class="num">${fmt(y.interest,0)}</td><td class="num">${fmt(y.endBalance,0)}</td></tr>
    `).join('');

    const maxTotal = Math.max(...years.map(y=>y.principal+y.interest), 1);
    el('yearlyChart').innerHTML = years.map(y=>{
      const totalH = Math.round(((y.principal+y.interest)/maxTotal)*130)+8;
      const intH = Math.round((y.interest/(y.principal+y.interest||1))*totalH);
      return `<div class="bar" style="height:${totalH}px;background:linear-gradient(to top, #2668b3 ${totalH-intH}px, #e88a12 0)"><span>${y.year}</span></div>`;
    }).join('');

    // full schedule (first N + toggle)
    el('scheduleBody').innerHTML = withExtra.rows.map(r=>`
      <tr><td>${r.period}</td><td class="num">${fmt(r.principalPaid,0)}</td><td class="num">${fmt(r.interest,0)}</td><td class="num">${fmt(r.balance,0)}</td></tr>
    `).join('');

    // comparison mode
    if(el('compareToggle').checked){
      el('loanBPanel').style.display='block';
      el('comparisonPanel').style.display='block';
      const loanB = computeLoan('b');
      const totalInterestB = loanB.base.totalInterest;
      el('compareBody').innerHTML = `
        <tr><th></th><th>Loan A</th><th>Loan B</th><th>Difference</th></tr>
        <tr><td>Payment / ${PERIOD_LABEL[loan.freq]}</td><td class="num">${fmt(loan.emi,0)}</td><td class="num">${fmt(loanB.emi,0)}</td><td class="num">${fmt(loan.emi-loanB.emi,0)}</td></tr>
        <tr><td>Total interest</td><td class="num">${fmt(loan.base.totalInterest,0)}</td><td class="num">${fmt(totalInterestB,0)}</td><td class="num">${fmt(loan.base.totalInterest-totalInterestB,0)}</td></tr>
        <tr><td>Total payment</td><td class="num">${fmt(loan.financed+loan.base.totalInterest,0)}</td><td class="num">${fmt(loanB.financed+totalInterestB,0)}</td><td class="num">${fmt((loan.financed+loan.base.totalInterest)-(loanB.financed+totalInterestB),0)}</td></tr>
        <tr><td>Payoff time</td><td class="num">${loan.base.rows.length} ${PERIOD_LABEL[loan.freq]}s</td><td class="num">${loanB.base.rows.length} ${PERIOD_LABEL[loan.freq]}s</td><td class="num">${loan.base.rows.length-loanB.base.rows.length}</td></tr>
      `;
    } else {
      el('loanBPanel').style.display='none';
      el('comparisonPanel').style.display='none';
    }

    saveToStorage();
  }

  function saveToStorage(){
    try{
      const ids=['Amount','Down','Rate','Years','freq','fees','extraPayment','bAmount','bDown','bRate','bYears'];
      const o={};
      ['Amount','Down','Rate','Years'].forEach(k=>{const n=el(k); if(n) o[k]=n.value;});
      ['freq','fees','extraPayment'].forEach(k=>{const n=el(k); if(n) o[k]=n.value;});
      ['bAmount','bDown','bRate','bYears'].forEach(k=>{const n=el(k); if(n) o[k]=n.value;});
      o.compare = el('compareToggle').checked;
      localStorage.setItem('clacora-loan-v1', JSON.stringify(o));
    }catch(e){}
  }
  function loadFromStorage(){
    try{
      const raw = localStorage.getItem('clacora-loan-v1');
      if(!raw) return;
      const o = JSON.parse(raw);
      Object.keys(o).forEach(k=>{ if(k==='compare') return; const n=el(k); if(n && o[k]!==undefined) n.value=o[k]; });
      if(o.compare) el('compareToggle').checked = true;
    }catch(e){}
  }

  function resetAll(){
    localStorage.removeItem('clacora-loan-v1');
    ['Amount','Down','Rate','Years','fees','extraPayment','bAmount','bDown','bRate','bYears'].forEach(id=>{ const n=el(id); if(n) n.value=''; });
    el('compareToggle').checked = false;
    el('Amount').value=3000000; el('Rate').value=15; el('Years').value=5;
    render();
  }

  function copyResult(){
    const text = `Loan EMI (Clacora Tools):\nPayment: PKR ${el('rEMI').textContent} ${el('rFreqLabel').textContent}\nTotal interest: PKR ${el('rTotalInterest').textContent}\nTotal payment: PKR ${el('rTotalPayment').textContent}`;
    navigator.clipboard?.writeText(text).then(()=>{
      const b=el('copyBtn'); const old=b.textContent; b.textContent='Copied!'; setTimeout(()=>b.textContent=old,1500);
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    loadFromStorage();
    if(!el('Amount').value){ el('Amount').value=3000000; el('Rate').value=15; el('Years').value=5; }
    ['Amount','Down','Rate','Years','freq','fees','extraPayment','bAmount','bDown','bRate','bYears'].forEach(id=>{
      const n = el(id); if(n) n.addEventListener('input', render);
    });
    el('compareToggle').addEventListener('change', render);
    el('showFullSchedule').addEventListener('click', ()=>{
      const box = el('fullScheduleWrap');
      const show = box.style.display==='none';
      box.style.display = show ? 'block':'none';
      el('showFullSchedule').textContent = show ? 'Hide full schedule' : 'Show full period-by-period schedule';
    });
    el('resetBtn').addEventListener('click', resetAll);
    el('copyBtn').addEventListener('click', copyResult);
    el('printBtn').addEventListener('click', ()=>window.print());
    el('shareBtn').addEventListener('click', ()=>{
      navigator.clipboard?.writeText(window.location.href);
      const b=el('shareBtn'); const old=b.textContent; b.textContent='Link copied!'; setTimeout(()=>b.textContent=old,1500);
    });
    render();
  });
})();
