#!/bin/bash
# Replace the placeholder domain (clacora-tools.example) with your real domain everywhere.
#
# Usage:
#   ./set-domain.sh yourdomain.com
#
# This rewrites canonical URLs, Open Graph tags, Twitter card tags,
# JSON-LD schema, and sitemap.xml in one pass. Run it once, right
# before you deploy, from inside the site/ folder.

set -e

if [ -z "$1" ]; then
  echo "Usage: ./set-domain.sh yourdomain.com"
  exit 1
fi

NEW_DOMAIN="$1"
OLD_DOMAIN="clacora-tools.example"

echo "Replacing $OLD_DOMAIN -> $NEW_DOMAIN in all .html, .xml and .txt files..."

find . -type f \( -name "*.html" -o -name "*.xml" -o -name "*.txt" \) \
  -exec sed -i.bak "s/${OLD_DOMAIN}/${NEW_DOMAIN}/g" {} \;

# remove the .bak backup files sed creates
find . -name "*.bak" -delete

echo "Done. Every canonical URL, Open Graph tag, Twitter card, JSON-LD"
echo "schema reference and sitemap.xml entry now points to ${NEW_DOMAIN}."
echo
echo "Don't forget to also update:"
echo "  - the contact form's mailto: address in contact/index.html, if needed"
echo "  - robots.txt (already updated by this script)"
