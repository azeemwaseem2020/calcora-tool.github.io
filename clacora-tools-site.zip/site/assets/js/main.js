// Shared across all pages: theme + tiny helpers
(function(){
  const root = document.documentElement;
  const KEY = 'clacora-theme';

  function apply(theme){
    if(theme === 'dark'){
      root.style.setProperty('--paper', '#0b1220');
      root.style.setProperty('--paper-raised', '#101a2e');
      root.style.setProperty('--ink', '#eef1f8');
      root.style.setProperty('--line', '#223055');
      root.style.setProperty('--line-soft', '#1a2645');
      root.style.setProperty('--muted', '#aab3c8');
      root.style.setProperty('--muted-2', '#7c869e');
      root.style.setProperty('--text-heading', '#f4f6fb');
      root.style.setProperty('--text-strong', '#d3dbec');
      root.style.setProperty('--header-bg', 'rgba(11,18,32,.86)');
      root.setAttribute('data-theme','dark');
    } else {
      root.removeAttribute('style');
      root.setAttribute('data-theme','light');
    }
  }

  const saved = localStorage.getItem(KEY) || 'light';
  apply(saved);

  document.addEventListener('DOMContentLoaded', function(){
    const btn = document.querySelector('[data-theme-toggle]');
    if(btn){
      btn.addEventListener('click', function(){
        const cur = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        localStorage.setItem(KEY, cur);
        apply(cur);
      });
    }
  });

  window.ClacoraTools = window.ClacoraTools || {};
  window.ClacoraTools.fmt = function(n, d){
    if(n === null || n === undefined || isNaN(n)) return '—';
    d = d === undefined ? 0 : d;
    return Number(n).toLocaleString('en-US', {maximumFractionDigits:d, minimumFractionDigits:d});
  };
})();
